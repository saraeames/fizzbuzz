$(document).ready(function(){
	
	// process fizzbuzz form
	$('#fbform').submit(function(e) {
		e.preventDefault();
		calculateFizzBuzz();
		window.location.href = 'results.html';  // so form fields aren't in URL
	});
	
	// open mobile nav
	$('header a.mobile-toggle').click(function (e) {
		e.preventDefault();
		$('nav.mobile').slideToggle();
	});

});

$('#resultsPage').ready(function(){  
	
	// get and display stored fizz data
	var resultFizz = [];
    resultFizz = sessionStorage.getItem('fizz');
    if (resultFizz) { 
		resultFizz = JSON.parse(resultFizz);
		$('#fizzTable').show(); // table should only show if there are results
		$('.noResultsFizz').hide();
		var fizzCount = resultFizz.length; 
		$('.fizzCount').text('' + fizzCount + ''); // update counter in header
		var fizzRows = ''; // string to build rows
		for (var i = 0; i < fizzCount; i++) { // loop through array items in fizz variable
			fizzRows = fizzRows + '<tr>';
			for (var j = 0; j < 5; j++) { // loop 5 times for the 5 fields in the inner array
				fizzRows = fizzRows + '<td>' + resultFizz[i][j] +  '</td>';
			}
			fizzRows = fizzRows + '</tr>';
		}
		$('#fizzTable').append(fizzRows); // add rows to table
    }
	
	// get and display stored buzz data
	var resultBuzz = [];
    resultBuzz = sessionStorage.getItem('buzz');
    if (resultBuzz) {
		resultBuzz = JSON.parse(resultBuzz);
		$('#buzzTable').show();  // table should only show if there are results
		$('.noResultsBuzz').hide();
		var buzzCount = resultBuzz.length; 
		$('.buzzCount').text('' + buzzCount + ''); // update counter in header
		var buzzRows = ''; // string to build rows
		for (var ii = 0; ii < buzzCount; ii++) { // loop through array items in buzz variable
			buzzRows = buzzRows + '<tr>';
			for (var jj = 0; jj < 5; jj++) { // loop 5 times for the 5 fields in the inner array
				buzzRows = buzzRows + '<td>' + resultBuzz[ii][jj] +  '</td>';
			}
			buzzRows = buzzRows + '</tr>';
		}
		$('#buzzTable').append(buzzRows); // add rows to table
    }
	
	// get and display stored fizzbuzz data
	var resultFizzBuzz = [];
    resultFizzBuzz = sessionStorage.getItem('fizzbuzz');
    if (resultFizzBuzz) {
		resultFizzBuzz = JSON.parse(resultFizzBuzz);
		$('#fizzbuzzTable').show();  // table should only show if there are results
		$('.noResultsFizzBuzz').hide();
		var fizzbuzzCount = resultFizzBuzz.length; 
		$('.fizzbuzzCount').text('' + fizzbuzzCount + ''); // update counter in header
		var fizzbuzzRows = ''; // string to build rows
		for (var iii = 0; iii < fizzbuzzCount; iii++) { // loop through arrayitems in fizzbuzz variable
			fizzbuzzRows = fizzbuzzRows + '<tr>';
			for (var jjj = 0; jjj < 5; jjj++) { // loop 5 times for the 5 fields in the inner array
				fizzbuzzRows = fizzbuzzRows + '<td>' + resultFizzBuzz[iii][jjj] +  '</td>';
			}
			fizzbuzzRows = fizzbuzzRows + '</tr>';
		}
		$('#fizzbuzzTable').append(fizzbuzzRows); // add rows to table
    }
	
	// get and display stored ungrouped data
	var resultUngrouped = [];
    resultUngrouped = sessionStorage.getItem('ungrouped');
    if (resultUngrouped) {
		resultUngrouped = JSON.parse(resultUngrouped);
		$('#ungroupedTable').show();  // table should only show if there are results
		$('.noResultsUngrouped').hide();
		var ungroupedCount = resultUngrouped.length; 
		$('.ungroupedCount').text('' + ungroupedCount + ''); // update counter in header
		var ungroupedRows = ''; // string to build rows
		for (var iiii = 0; iiii < ungroupedCount; iiii++) { // loop through array items in fizzbuzz variable
			ungroupedRows = ungroupedRows + '<tr>';
			for (var jjjj = 0; jjjj < 5; jjjj++) { // loop 5 times for the 5 fields in the inner array
				ungroupedRows = ungroupedRows + '<td>' + resultUngrouped[iiii][jjjj] +  '</td>';
			}
			ungroupedRows = ungroupedRows + '</tr>';
		}
		$('#ungroupedTable').append(ungroupedRows); // add rows to table
    }

});


function calculateFizzBuzz() {	
	
	var arbInteger = $('#fbform #int').val();
	
	// put form data in an array
	var formData = [
		$('#fbform #fullname').val(),
		$('#fbform #gender').val(),
		$('#fbform #mstatus').val(),
		$('#fbform #dob').val(),
		$('#fbform #int').val()
	];

	// arbitrary integer is divisible by both 3 and 5
	if (arbInteger % 3 === 0 && arbInteger % 5 === 0) {
		var ssFizzBuzz = sessionStorage.getItem('fizzbuzz');
		if (ssFizzBuzz) { // if there is current data stored
			ssFizzBuzz = JSON.parse(ssFizzBuzz);
			ssFizzBuzz.push(formData);
			sessionStorage.setItem('fizzbuzz', JSON.stringify(ssFizzBuzz));
		} else {  // no current data - first time setting sessionStorage
			// need multidimensional for the first time sessionStorage
			var multiFizzBuzzData = [formData]; 
			sessionStorage.setItem('fizzbuzz', JSON.stringify(multiFizzBuzzData));
		}
	// arbitrary integer is divisible by 3
	} else if (arbInteger % 3 === 0) {
		var ssFizz = sessionStorage.getItem('fizz');
		if (ssFizz) { // if there is current data stored
			ssFizz = JSON.parse(ssFizz);
			ssFizz.push(formData);
			sessionStorage.setItem('fizz', JSON.stringify(ssFizz));
		} else {  // no current data - first time setting sessionStorage
			// need multidimensional for the first time sessionStorage
			var multiFizzData = [formData]; 
			sessionStorage.setItem('fizz', JSON.stringify(multiFizzData));
		}
	// arbitrary integer is divisible by 5
	} else if (arbInteger % 5 === 0) {
		var ssBuzz = sessionStorage.getItem('buzz');
		if (ssBuzz) { // if there is current data stored
			ssBuzz = JSON.parse(ssBuzz);
			ssBuzz.push(formData);
			sessionStorage.setItem('buzz', JSON.stringify(ssBuzz));
		} else {  // no current data - first time setting sessionStorage
			// need multidimensional for the first time sessionStorage
			var multiBuzzData = [formData]; 
			sessionStorage.setItem('buzz', JSON.stringify(multiBuzzData));
		}  
	// doesn't fall into any category
	} else {
		var ssUngrouped = sessionStorage.getItem('ungrouped');
		if (ssUngrouped) { // if there is current data stored
			ssUngrouped = JSON.parse(ssUngrouped);
			ssUngrouped.push(formData);
			sessionStorage.setItem('ungrouped', JSON.stringify(ssUngrouped));
		} else {  // no current data - first time setting sessionStorage
			// need multidimensional for the first time sessionStorage
			var multiUngroupedData = [formData]; 
			sessionStorage.setItem('ungrouped', JSON.stringify(multiUngroupedData));
		}
	}

}







